package com.libra.vaccine.VO;

public class DataVO {

    private  int pfizer,moderna,az,act;
    private  String oneDay,twoDay,threeDay,fourDay,fiveDay;

    public int getPfizer() {
        return pfizer;
    }

    public void setPfizer(int pfizer) {
        this.pfizer = pfizer;
    }

    public int getModerna() {
        return moderna;
    }

    public void setModerna(int moderna) {
        this.moderna = moderna;
    }

    public int getAz() {
        return az;
    }

    public void setAz(int az) {
        this.az = az;
    }

    public int getAct() {
        return act;
    }

    public void setAct(int act) {
        this.act = act;
    }

    public String getOneDay() {
        return oneDay;
    }

    public void setOneDay(String oneDay) {
        this.oneDay = oneDay;
    }

    public String getTwoDay() {
        return twoDay;
    }

    public void setTwoDay(String twoDay) {
        this.twoDay = twoDay;
    }

    public String getThreeDay() {
        return threeDay;
    }

    public void setThreeDay(String threeDay) {
        this.threeDay = threeDay;
    }

    public String getFourDay() {
        return fourDay;
    }

    public void setFourDay(String fourDay) {
        this.fourDay = fourDay;
    }

    public String getFiveDay() {
        return fiveDay;
    }

    public void setFiveDay(String fiveDay) {
        this.fiveDay = fiveDay;
    }
}
