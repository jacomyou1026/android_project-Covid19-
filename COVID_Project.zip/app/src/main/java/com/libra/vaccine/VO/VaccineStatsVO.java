package com.libra.vaccine.VO;

public class VaccineStatsVO {

    private  String percent,all,today,sixty;

    public String getSixty() {
        return sixty;
    }

    public void setSixty(String sixty) {
        this.sixty = sixty;
    }

    public String getPercent() {
        return percent;
    }

    public void setPercent(String percent) {
        this.percent = percent;
    }

    public String getAll() {
        return all;
    }

    public void setAll(String all) {
        this.all = all;
    }

    public String getToday() {
        return today;
    }

    public void setToday(String today) {
        this.today = today;
    }

}
